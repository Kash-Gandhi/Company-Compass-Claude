
-- Create app_role enum
create type public.app_role as enum ('admin', 'user');

-- Create department enum
create type public.department as enum ('sales', 'operations', 'hr', 'admin');

-- Profiles table
create table public.profiles (
    id uuid primary key references auth.users(id) on delete cascade,
    email text,
    full_name text,
    avatar_url text,
    is_approved boolean default false,
    created_at timestamptz default now(),
    updated_at timestamptz default now()
);
alter table public.profiles enable row level security;

-- User roles table
create table public.user_roles (
    id uuid primary key default gen_random_uuid(),
    user_id uuid references auth.users(id) on delete cascade not null,
    role app_role not null default 'user',
    created_at timestamptz default now(),
    unique (user_id, role)
);
alter table public.user_roles enable row level security;

-- User departments table
create table public.user_departments (
    id uuid primary key default gen_random_uuid(),
    user_id uuid references auth.users(id) on delete cascade not null,
    department department not null,
    created_at timestamptz default now(),
    unique (user_id, department)
);
alter table public.user_departments enable row level security;

-- Documents table
create table public.documents (
    id uuid primary key default gen_random_uuid(),
    title text not null,
    content text not null default '',
    department department not null,
    source_url text,
    created_by uuid references auth.users(id),
    created_at timestamptz default now(),
    updated_at timestamptz default now()
);
alter table public.documents enable row level security;

-- Security definer function to check roles
create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.user_roles
    where user_id = _user_id
      and role = _role
  )
$$;

-- Security definer function to check department membership
create or replace function public.has_department(_user_id uuid, _dept department)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.user_departments
    where user_id = _user_id
      and department = _dept
  )
$$;

-- Security definer function to check if user is approved
create or replace function public.is_approved(_user_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.profiles
    where id = _user_id
      and is_approved = true
  )
$$;

-- RLS Policies for profiles
create policy "Users can view own profile"
  on public.profiles for select
  to authenticated
  using (id = auth.uid());

create policy "Admins can view all profiles"
  on public.profiles for select
  to authenticated
  using (public.has_role(auth.uid(), 'admin'));

create policy "Admins can update all profiles"
  on public.profiles for update
  to authenticated
  using (public.has_role(auth.uid(), 'admin'));

create policy "Users can update own profile"
  on public.profiles for update
  to authenticated
  using (id = auth.uid())
  with check (id = auth.uid());

create policy "Profile auto-creation on signup"
  on public.profiles for insert
  with check (true);

-- RLS Policies for user_roles
create policy "Admins can manage roles"
  on public.user_roles for all
  to authenticated
  using (public.has_role(auth.uid(), 'admin'));

create policy "Users can view own roles"
  on public.user_roles for select
  to authenticated
  using (user_id = auth.uid());

-- RLS Policies for user_departments
create policy "Admins can manage departments"
  on public.user_departments for all
  to authenticated
  using (public.has_role(auth.uid(), 'admin'));

create policy "Users can view own departments"
  on public.user_departments for select
  to authenticated
  using (user_id = auth.uid());

-- RLS Policies for documents
create policy "Approved users can view documents in their department"
  on public.documents for select
  to authenticated
  using (
    public.is_approved(auth.uid()) and (
      public.has_role(auth.uid(), 'admin') or
      public.has_department(auth.uid(), department)
    )
  );

create policy "Admins can insert documents"
  on public.documents for insert
  to authenticated
  with check (public.has_role(auth.uid(), 'admin'));

create policy "Admins can update documents"
  on public.documents for update
  to authenticated
  using (public.has_role(auth.uid(), 'admin'));

create policy "Admins can delete documents"
  on public.documents for delete
  to authenticated
  using (public.has_role(auth.uid(), 'admin'));

-- Trigger to create profile on signup
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name, avatar_url)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data ->> 'full_name', new.raw_user_meta_data ->> 'name', ''),
    coalesce(new.raw_user_meta_data ->> 'avatar_url', '')
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();
