
drop policy if exists "Profile auto-creation on signup" on public.profiles;
