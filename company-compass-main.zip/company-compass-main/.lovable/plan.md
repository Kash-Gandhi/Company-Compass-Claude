
Goal: fix the site getting stuck and not loading after sign-in.

What I found
- Your account data is actually correct in the backend:
  - `kashvi@pacifiqueinvestments.com` is approved
  - it has the `admin` role
- The app is still not opening because the auth bootstrapping is hanging on the frontend.
- The strongest signal is:
  - session replay shows the app sitting on the loading spinner
  - network requests for `profiles` and `user_roles` succeed
  - `AuthContext.tsx` uses an `async` `onAuthStateChange` callback and awaits Supabase queries inside it

Actual issue
- This is not mainly a permissions problem anymore.
- The likely root cause is an auth deadlock/stall pattern:
  - `supabase.auth.onAuthStateChange(async (...) => { await fetchUserData(...) })`
  - inside that callback, `fetchUserData` performs more Supabase calls
- That pattern is known to cause auth initialization hangs because the auth callback can run while the auth client still holds internal state/locks.
- Result: `loading` may never resolve cleanly, so the site stays on the spinner and feels like it “does not load”.

Implementation plan
1. Refactor `src/contexts/AuthContext.tsx`
- Remove the `async` callback passed directly to `supabase.auth.onAuthStateChange`.
- Create a separate helper like `initializeFromSession(session)` that:
  - sets `session` and `user`
  - clears profile/roles/departments when signed out
  - fetches profile/roles/departments for signed-in users
  - always ends by setting `loading` to `false`
- In `onAuthStateChange`, call that helper without awaiting inline in the subscriber. Use a deferred call pattern so data loading happens after auth state notification completes.

2. Make loading state deterministic
- Set `loading(true)` before the initial session bootstrap starts.
- Ensure all code paths end with `loading(false)`, including fetch failures.
- If profile/roles queries fail, avoid leaving the app in an infinite spinner.

3. Harden `fetchUserData`
- Reset `profile`, `roles`, and `departments` explicitly when a query returns no data.
- Avoid stale state from previous sessions.
- Keep role/admin evaluation based on freshly loaded arrays.

4. Verify route behavior against current logic
- Keep `ProtectedRoute` logic as-is once auth loading is fixed:
  - no user → `/login`
  - signed-in but not approved and not admin → `/pending`
  - approved/admin → app shell
- This should work because the backend now already returns approved/admin correctly.

5. Optional cleanup after the fix
- Investigate the React warning:
  - “Function components cannot be given refs”
- It is probably unrelated to the loading failure, but I would review route/layout composition after the auth fix in case a wrapper component is triggering noise in development.

Files involved
- `src/contexts/AuthContext.tsx` — main fix
- `src/components/ProtectedRoute.tsx` — verify behavior only, likely no change needed
- `src/App.tsx` — verify route nesting only, likely no change needed

Technical details
```text
Current risky flow:
onAuthStateChange(async () => {
  await fetchUserData()
})

fetchUserData() -> supabase.from(...).select(...)
```

```text
Safer flow:
onAuthStateChange((event, session) => {
  queueMicrotask / setTimeout(() => {
    void initializeFromSession(session)
  })
})
```

Expected outcome
- The spinner should stop hanging
- After sign-in, approved admin users should land in the dashboard
- Non-approved users should only see the pending page when their backend state truly says so
