import { useAuth } from '@/contexts/AuthContext';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { FileText, Users, ShieldCheck, Briefcase, HeartHandshake, Settings, LogOut, Menu, X, Building2 } from 'lucide-react';
import { useState } from 'react';
import { cn } from '@/lib/utils';

const DEPARTMENTS = [
  { key: 'sales', label: 'Sales', icon: Briefcase },
  { key: 'operations', label: 'Operations', icon: Settings },
  { key: 'hr', label: 'HR', icon: HeartHandshake },
  { key: 'admin', label: 'Admin', icon: ShieldCheck },
] as const;

const AppLayout = ({ children }: { children: React.ReactNode }) => {
  const { profile, departments, isAdmin, signOut } = useAuth();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const visibleDepartments = isAdmin
    ? DEPARTMENTS
    : DEPARTMENTS.filter(d => departments.includes(d.key));

  const initials = profile?.full_name
    ? profile.full_name.split(' ').map(n => n[0]).join('').toUpperCase()
    : profile?.email?.[0]?.toUpperCase() ?? '?';

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="mx-auto max-w-7xl flex h-16 items-center justify-between px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3">
            <button
              className="sm:hidden p-2 -ml-2 rounded-md hover:bg-accent"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
            <Link to="/" className="flex items-center gap-2.5">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
                <Building2 className="h-4 w-4 text-primary-foreground" />
              </div>
              <span className="font-semibold text-lg hidden sm:inline">Company Portal</span>
            </Link>
          </div>

          {/* Desktop nav */}
          <nav className="hidden sm:flex items-center gap-1">
            <Link to="/">
              <Button
                variant={location.pathname === '/' ? 'secondary' : 'ghost'}
                size="sm"
              >
                <FileText className="h-4 w-4 mr-1.5" />
                Dashboard
              </Button>
            </Link>
            {visibleDepartments.map(dept => (
              <Link key={dept.key} to={`/department/${dept.key}`}>
                <Button
                  variant={location.pathname === `/department/${dept.key}` ? 'secondary' : 'ghost'}
                  size="sm"
                >
                  <dept.icon className="h-4 w-4 mr-1.5" />
                  {dept.label}
                </Button>
              </Link>
            ))}
            {isAdmin && (
              <Link to="/admin">
                <Button
                  variant={location.pathname.startsWith('/admin') ? 'secondary' : 'ghost'}
                  size="sm"
                >
                  <Users className="h-4 w-4 mr-1.5" />
                  Admin
                </Button>
              </Link>
            )}
          </nav>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-9 w-9 rounded-full">
                <Avatar className="h-9 w-9">
                  <AvatarImage src={profile?.avatar_url ?? undefined} />
                  <AvatarFallback className="bg-primary/10 text-primary text-sm font-medium">
                    {initials}
                  </AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <div className="px-2 py-1.5">
                <p className="text-sm font-medium">{profile?.full_name || 'User'}</p>
                <p className="text-xs text-muted-foreground">{profile?.email}</p>
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={signOut}>
                <LogOut className="mr-2 h-4 w-4" />
                Sign out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Mobile nav */}
        {mobileMenuOpen && (
          <nav className="sm:hidden border-t border-border p-2 space-y-1">
            <Link to="/" onClick={() => setMobileMenuOpen(false)}>
              <Button variant={location.pathname === '/' ? 'secondary' : 'ghost'} size="sm" className="w-full justify-start">
                <FileText className="h-4 w-4 mr-2" /> Dashboard
              </Button>
            </Link>
            {visibleDepartments.map(dept => (
              <Link key={dept.key} to={`/department/${dept.key}`} onClick={() => setMobileMenuOpen(false)}>
                <Button variant={location.pathname === `/department/${dept.key}` ? 'secondary' : 'ghost'} size="sm" className="w-full justify-start">
                  <dept.icon className="h-4 w-4 mr-2" /> {dept.label}
                </Button>
              </Link>
            ))}
            {isAdmin && (
              <Link to="/admin" onClick={() => setMobileMenuOpen(false)}>
                <Button variant={location.pathname.startsWith('/admin') ? 'secondary' : 'ghost'} size="sm" className="w-full justify-start">
                  <Users className="h-4 w-4 mr-2" /> Admin
                </Button>
              </Link>
            )}
          </nav>
        )}
      </header>

      {/* Main content */}
      <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-6">
        {children}
      </main>
    </div>
  );
};

export default AppLayout;
