import { useParams, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { FileText, ArrowLeft, Calendar } from 'lucide-react';
import { format } from 'date-fns';
import { useState } from 'react';

const DEPT_LABELS: Record<string, string> = {
  sales: 'Sales',
  operations: 'Operations',
  hr: 'HR',
  admin: 'Admin',
};

const DepartmentPage = () => {
  const { dept } = useParams<{ dept: string }>();
  const { isAdmin, departments } = useAuth();
  const [selectedDoc, setSelectedDoc] = useState<string | null>(null);

  const hasAccess = isAdmin || departments.includes(dept as any);

  const { data: documents, isLoading } = useQuery({
    queryKey: ['documents', dept],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('documents')
        .select('*')
        .eq('department', dept as "sales" | "operations" | "hr" | "admin")
        .order('updated_at', { ascending: false });

      if (error) throw error;
      return data;
    },
    enabled: hasAccess && !!dept,
  });

  if (!hasAccess) {
    return (
      <div className="text-center py-20">
        <p className="text-muted-foreground">You don't have access to this department.</p>
        <Link to="/" className="text-primary hover:underline mt-2 inline-block">
          Back to Dashboard
        </Link>
      </div>
    );
  }

  const selectedDocument = documents?.find(d => d.id === selectedDoc);

  if (selectedDocument) {
    return (
      <div className="space-y-4">
        <button
          onClick={() => setSelectedDoc(null)}
          className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back to {DEPT_LABELS[dept!] || dept}
        </button>
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2 mb-2">
              <Badge variant="secondary">{DEPT_LABELS[dept!]}</Badge>
              {selectedDocument.updated_at && (
                <span className="text-xs text-muted-foreground">
                  Updated {format(new Date(selectedDocument.updated_at), 'MMM d, yyyy')}
                </span>
              )}
            </div>
            <CardTitle className="text-2xl">{selectedDocument.title}</CardTitle>
          </CardHeader>
          <CardContent>
            <div
              className="doc-content prose max-w-none"
              dangerouslySetInnerHTML={{ __html: selectedDocument.content }}
            />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Link to="/" className="text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft className="h-5 w-5" />
        </Link>
        <div>
          <h1 className="text-2xl font-bold">{DEPT_LABELS[dept!] || dept} Documents</h1>
          <p className="text-muted-foreground text-sm">
            Policies, SOPs, and guidelines for the {DEPT_LABELS[dept!] || dept} team
          </p>
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-24 bg-muted animate-pulse rounded-lg" />
          ))}
        </div>
      ) : documents && documents.length > 0 ? (
        <div className="space-y-3">
          {documents.map(doc => (
            <Card
              key={doc.id}
              className="cursor-pointer hover:shadow-md transition-all hover:border-primary/20"
              onClick={() => setSelectedDoc(doc.id)}
            >
              <CardHeader className="py-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 mt-0.5">
                      <FileText className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-base">{doc.title}</CardTitle>
                      <CardDescription className="mt-1 flex items-center gap-1.5">
                        <Calendar className="h-3 w-3" />
                        {doc.updated_at && format(new Date(doc.updated_at), 'MMM d, yyyy')}
                      </CardDescription>
                    </div>
                  </div>
                </div>
              </CardHeader>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="py-12 text-center">
            <FileText className="mx-auto h-10 w-10 text-muted-foreground/50 mb-3" />
            <p className="text-muted-foreground">No documents in this department yet.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default DepartmentPage;
