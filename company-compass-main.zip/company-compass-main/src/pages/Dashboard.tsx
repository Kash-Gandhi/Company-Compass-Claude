import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import { Briefcase, Settings, HeartHandshake, ShieldCheck, FileText, ArrowRight } from 'lucide-react';

const DEPARTMENTS = [
  { key: 'sales', label: 'Sales', description: 'Sales policies, playbooks, and procedures', icon: Briefcase, color: 'bg-blue-500/10 text-blue-600' },
  { key: 'operations', label: 'Operations', description: 'Operational SOPs and guidelines', icon: Settings, color: 'bg-green-500/10 text-green-600' },
  { key: 'hr', label: 'HR', description: 'HR policies, handbooks, and compliance', icon: HeartHandshake, color: 'bg-purple-500/10 text-purple-600' },
  { key: 'admin', label: 'Admin', description: 'Administrative procedures and protocols', icon: ShieldCheck, color: 'bg-orange-500/10 text-orange-600' },
] as const;

const Dashboard = () => {
  const { profile, departments, isAdmin } = useAuth();

  const visibleDepartments = isAdmin
    ? DEPARTMENTS
    : DEPARTMENTS.filter(d => departments.includes(d.key));

  return (
    <div className="space-y-8">
      {/* Welcome */}
      <div>
        <h1 className="text-3xl font-bold tracking-tight">
          Welcome back, {profile?.full_name?.split(' ')[0] || 'there'}
        </h1>
        <p className="mt-1 text-muted-foreground">
          Access your company's policies, SOPs, and internal documentation.
        </p>
      </div>

      {/* Department cards */}
      <div>
        <h2 className="text-lg font-semibold mb-4">Your Departments</h2>
        {visibleDepartments.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <FileText className="mx-auto h-10 w-10 text-muted-foreground/50 mb-3" />
              <p className="text-muted-foreground">No departments assigned yet. Contact your administrator.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {visibleDepartments.map(dept => (
              <Link key={dept.key} to={`/department/${dept.key}`}>
                <Card className="group hover:shadow-md transition-all hover:border-primary/20 cursor-pointer h-full">
                  <CardHeader className="pb-3">
                    <div className={`inline-flex h-10 w-10 items-center justify-center rounded-lg ${dept.color}`}>
                      <dept.icon className="h-5 w-5" />
                    </div>
                    <CardTitle className="text-lg mt-3 flex items-center justify-between">
                      {dept.label}
                      <ArrowRight className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription>{dept.description}</CardDescription>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
