import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import { Users, FileText, Plus, Trash2, Check, X, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

const DEPARTMENTS = ['sales', 'operations', 'hr', 'admin'] as const;
const DEPT_LABELS: Record<string, string> = {
  sales: 'Sales',
  operations: 'Operations',
  hr: 'HR',
  admin: 'Admin',
};

const AdminPage = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch all profiles
  const { data: profiles, isLoading: profilesLoading } = useQuery({
    queryKey: ['admin-profiles'],
    queryFn: async () => {
      const { data, error } = await supabase.from('profiles').select('*').order('created_at', { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  // Fetch all user_roles
  const { data: allRoles } = useQuery({
    queryKey: ['admin-roles'],
    queryFn: async () => {
      const { data, error } = await supabase.from('user_roles').select('*');
      if (error) throw error;
      return data;
    },
  });

  // Fetch all user_departments
  const { data: allDepts } = useQuery({
    queryKey: ['admin-departments'],
    queryFn: async () => {
      const { data, error } = await supabase.from('user_departments').select('*');
      if (error) throw error;
      return data;
    },
  });

  // Fetch all documents
  const { data: documents, isLoading: docsLoading } = useQuery({
    queryKey: ['admin-documents'],
    queryFn: async () => {
      const { data, error } = await supabase.from('documents').select('*').order('updated_at', { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  // Approve/disapprove user
  const toggleApproval = useMutation({
    mutationFn: async ({ userId, approved }: { userId: string; approved: boolean }) => {
      const { error } = await supabase.from('profiles').update({ is_approved: approved }).eq('id', userId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-profiles'] });
      toast({ title: 'User updated' });
    },
  });

  // Toggle admin role
  const toggleAdmin = useMutation({
    mutationFn: async ({ userId, isAdmin }: { userId: string; isAdmin: boolean }) => {
      if (isAdmin) {
        const { error } = await supabase.from('user_roles').insert({ user_id: userId, role: 'admin' });
        if (error) throw error;
      } else {
        const { error } = await supabase.from('user_roles').delete().eq('user_id', userId).eq('role', 'admin');
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-roles'] });
      toast({ title: 'Role updated' });
    },
  });

  // Toggle department
  const toggleDepartment = useMutation({
    mutationFn: async ({ userId, department, add }: { userId: string; department: string; add: boolean }) => {
      if (add) {
        const { error } = await supabase.from('user_departments').insert({ user_id: userId, department: department as any });
        if (error) throw error;
      } else {
        const { error } = await supabase.from('user_departments').delete().eq('user_id', userId).eq('department', department as any);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-departments'] });
      toast({ title: 'Department updated' });
    },
  });

  // Delete document
  const deleteDoc = useMutation({
    mutationFn: async (docId: string) => {
      const { error } = await supabase.from('documents').delete().eq('id', docId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-documents'] });
      toast({ title: 'Document deleted' });
    },
  });

  const getUserRoles = (userId: string) => allRoles?.filter(r => r.user_id === userId) ?? [];
  const getUserDepts = (userId: string) => allDepts?.filter(d => d.user_id === userId) ?? [];
  const isUserAdmin = (userId: string) => getUserRoles(userId).some(r => r.role === 'admin');

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Link to="/" className="text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft className="h-5 w-5" />
        </Link>
        <h1 className="text-2xl font-bold">Admin Panel</h1>
      </div>

      <Tabs defaultValue="users">
        <TabsList>
          <TabsTrigger value="users" className="gap-1.5">
            <Users className="h-4 w-4" /> Users
          </TabsTrigger>
          <TabsTrigger value="documents" className="gap-1.5">
            <FileText className="h-4 w-4" /> Documents
          </TabsTrigger>
        </TabsList>

        {/* Users Tab */}
        <TabsContent value="users" className="space-y-4">
          {profilesLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map(i => <div key={i} className="h-20 bg-muted animate-pulse rounded-lg" />)}
            </div>
          ) : (
            profiles?.map(p => (
              <Card key={p.id}>
                <CardContent className="py-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="min-w-0">
                      <p className="font-medium truncate">{p.full_name || 'Unnamed'}</p>
                      <p className="text-sm text-muted-foreground truncate">{p.email}</p>
                      <div className="flex flex-wrap gap-1 mt-2">
                        {isUserAdmin(p.id) && <Badge>Admin</Badge>}
                        {getUserDepts(p.id).map(d => (
                          <Badge key={d.id} variant="secondary">{DEPT_LABELS[d.department]}</Badge>
                        ))}
                      </div>
                    </div>
                    <div className="flex flex-col gap-3 sm:items-end shrink-0">
                      <div className="flex items-center gap-2">
                        <Label htmlFor={`approved-${p.id}`} className="text-sm">Approved</Label>
                        <Switch
                          id={`approved-${p.id}`}
                          checked={p.is_approved ?? false}
                          onCheckedChange={(checked) => toggleApproval.mutate({ userId: p.id, approved: checked })}
                        />
                      </div>
                      <div className="flex items-center gap-2">
                        <Label htmlFor={`admin-${p.id}`} className="text-sm">Admin</Label>
                        <Switch
                          id={`admin-${p.id}`}
                          checked={isUserAdmin(p.id)}
                          onCheckedChange={(checked) => toggleAdmin.mutate({ userId: p.id, isAdmin: checked })}
                        />
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {DEPARTMENTS.map(dept => {
                          const hasDept = getUserDepts(p.id).some(d => d.department === dept);
                          return (
                            <label key={dept} className="flex items-center gap-1.5 text-sm cursor-pointer">
                              <Checkbox
                                checked={hasDept}
                                onCheckedChange={(checked) =>
                                  toggleDepartment.mutate({ userId: p.id, department: dept, add: !!checked })
                                }
                              />
                              {DEPT_LABELS[dept]}
                            </label>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        {/* Documents Tab */}
        <TabsContent value="documents" className="space-y-4">
          <AddDocumentDialog />
          {docsLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map(i => <div key={i} className="h-20 bg-muted animate-pulse rounded-lg" />)}
            </div>
          ) : documents && documents.length > 0 ? (
            documents.map(doc => (
              <Card key={doc.id}>
                <CardContent className="py-4">
                  <div className="flex items-center justify-between gap-4">
                    <div className="min-w-0">
                      <p className="font-medium truncate">{doc.title}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="secondary">{DEPT_LABELS[doc.department]}</Badge>
                        {doc.source_url && (
                          <a href={doc.source_url} target="_blank" rel="noopener noreferrer" className="text-xs text-primary hover:underline">
                            Source
                          </a>
                        )}
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-destructive hover:text-destructive shrink-0"
                      onClick={() => deleteDoc.mutate(doc.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="py-12 text-center">
                <FileText className="mx-auto h-10 w-10 text-muted-foreground/50 mb-3" />
                <p className="text-muted-foreground">No documents yet. Add your first document above.</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

function AddDocumentDialog() {
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [department, setDepartment] = useState<string>('');
  const [sourceUrl, setSourceUrl] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const addDoc = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from('documents').insert({
        title,
        content,
        department: department as any,
        source_url: sourceUrl || null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-documents'] });
      toast({ title: 'Document added' });
      setOpen(false);
      setTitle('');
      setContent('');
      setDepartment('');
      setSourceUrl('');
    },
    onError: (error) => {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    },
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="h-4 w-4 mr-1.5" />
          Add Document
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add New Document</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 pt-2">
          <div className="space-y-2">
            <Label>Title</Label>
            <Input value={title} onChange={e => setTitle(e.target.value)} placeholder="e.g. Employee Handbook" />
          </div>
          <div className="space-y-2">
            <Label>Department</Label>
            <Select value={department} onValueChange={setDepartment}>
              <SelectTrigger>
                <SelectValue placeholder="Select department" />
              </SelectTrigger>
              <SelectContent>
                {DEPARTMENTS.map(dept => (
                  <SelectItem key={dept} value={dept}>{DEPT_LABELS[dept]}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Source URL (optional)</Label>
            <Input value={sourceUrl} onChange={e => setSourceUrl(e.target.value)} placeholder="https://docs.google.com/..." />
          </div>
          <div className="space-y-2">
            <Label>Content (HTML supported)</Label>
            <Textarea
              value={content}
              onChange={e => setContent(e.target.value)}
              placeholder="Paste your document content here. HTML formatting is supported."
              rows={12}
            />
          </div>
          <Button
            onClick={() => addDoc.mutate()}
            disabled={!title || !department || addDoc.isPending}
            className="w-full"
          >
            {addDoc.isPending ? 'Adding...' : 'Add Document'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default AdminPage;
